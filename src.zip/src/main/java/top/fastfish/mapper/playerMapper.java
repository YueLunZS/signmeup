package top.fastfish.mapper;

import top.fastfish.model.dbo.player;
import top.fastfish.model.pojo.user;

public interface playerMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(player record);

    int insertSelective(player record);

    player selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(player record);

    int updateByPrimaryKey(player record);

    user checkWithTEL(String account, String pass);

    user checkWithAccount(String account, String pass);
}