package top.fastfish.mapper;

import top.fastfish.model.dbo.wallet;

public interface walletMapper {
    int deleteByPrimaryKey(Integer walletId);

    int insert(wallet record);

    int insertSelective(wallet record);

    wallet selectByPrimaryKey(Integer walletId);

    int updateByPrimaryKeySelective(wallet record);

    int updateByPrimaryKey(wallet record);
}