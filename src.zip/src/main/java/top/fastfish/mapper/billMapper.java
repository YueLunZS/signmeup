package top.fastfish.mapper;

import top.fastfish.model.dbo.bill;

public interface billMapper {
    int deleteByPrimaryKey(Integer billId);

    int insert(bill record);

    int insertSelective(bill record);

    bill selectByPrimaryKey(Integer billId);

    int updateByPrimaryKeySelective(bill record);

    int updateByPrimaryKey(bill record);
}