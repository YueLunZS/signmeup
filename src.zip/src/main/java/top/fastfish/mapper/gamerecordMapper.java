package top.fastfish.mapper;

import top.fastfish.model.dbo.gamerecord;

public interface gamerecordMapper {
    int deleteByPrimaryKey(Integer gameId);

    int insert(gamerecord record);

    int insertSelective(gamerecord record);

    gamerecord selectByPrimaryKey(Integer gameId);

    int updateByPrimaryKeySelective(gamerecord record);

    int updateByPrimaryKey(gamerecord record);

    int selectByCreatetime(String s);
}