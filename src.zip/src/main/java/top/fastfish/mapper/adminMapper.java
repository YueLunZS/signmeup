package top.fastfish.mapper;

import top.fastfish.model.dbo.admin;
import top.fastfish.model.pojo.user;

public interface adminMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(admin record);

    int insertSelective(admin record);

    admin selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(admin record);

    int updateByPrimaryKey(admin record);

    user checkWithAccount(String account, String pass);
}