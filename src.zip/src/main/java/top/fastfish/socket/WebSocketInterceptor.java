package top.fastfish.socket;

/**
 * @author         原文：https://blog.csdn.net/qq_36476972/article/details/80111487
 * @version 1.0
 * Description: WebSocket拦截器
 * @date 2018/11/6
 */

import org.apache.log4j.Logger;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;
import top.fastfish.model.dbo.admin;

import javax.servlet.http.HttpSession;
import java.util.Map;


/**
 *@Title WebSocketInterceptor.java
 *@description:  WebSocket 适配器 拦截器
 *@time 创建时间：2018年4月26日 上午9:16:09
 **/
public class WebSocketInterceptor implements HandshakeInterceptor{

    private final static Logger log=Logger.getLogger(WebSocketInterceptor.class);

    @Override
    public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler handler, Exception exceptions) {
        log.info("=================执行 afterHandshake ：handler: "+handler+"exceptions: "+exceptions);
    }


    @Override
    public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler handler,
                                   Map<String, Object> map) throws Exception {
        log.info("==================执行 beforeHandshake ：handler: "+handler+"map: "+map.values());
        if(request instanceof ServerHttpRequest){
            ServletServerHttpRequest servletRequest = (ServletServerHttpRequest) request;
            HttpSession session = servletRequest.getServletRequest().getSession();
            if(session!=null){
                admin userA=(admin)session.getAttribute("uAdmin");
                map.put(String.valueOf(userA.getId()), userA);
            }
        }
        return true;
    }

}
