package top.fastfish.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 异常统一处理
 * @date 2018/10/26
 */
@Provider
public class exceptionHandler implements ExceptionMapper<Throwable> {

    @Override
    public Response toResponse(Throwable e) {

        return null;
    }

}

