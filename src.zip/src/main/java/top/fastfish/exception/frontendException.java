package top.fastfish.exception;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 传往erorrPage的异常消息
 * @date 2018/10/26
 */
public class frontendException{
    private String msg ;

    public frontendException(String msg){
        this.msg = msg;
    }
}
