package top.fastfish.model.dbo;

public class wallet {
    private Integer walletId;

    private String walletKey;

    private Integer playerId;

    private String borntime;

    private String updatetime;

    private String walletRemainder;

    private String drawAmount;

    private String blank1;

    private String blank2;

    private String blank3;

    public Integer getWalletId() {
        return walletId;
    }

    public void setWalletId(Integer walletId) {
        this.walletId = walletId;
    }

    public String getWalletKey() {
        return walletKey;
    }

    public void setWalletKey(String walletKey) {
        this.walletKey = walletKey == null ? null : walletKey.trim();
    }

    public Integer getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Integer playerId) {
        this.playerId = playerId;
    }

    public String getBorntime() {
        return borntime;
    }

    public void setBorntime(String borntime) {
        this.borntime = borntime == null ? null : borntime.trim();
    }

    public String getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(String updatetime) {
        this.updatetime = updatetime == null ? null : updatetime.trim();
    }

    public String getWalletRemainder() {
        return walletRemainder;
    }

    public void setWalletRemainder(String walletRemainder) {
        this.walletRemainder = walletRemainder == null ? null : walletRemainder.trim();
    }

    public String getDrawAmount() {
        return drawAmount;
    }

    public void setDrawAmount(String drawAmount) {
        this.drawAmount = drawAmount == null ? null : drawAmount.trim();
    }

    public String getBlank1() {
        return blank1;
    }

    public void setBlank1(String blank1) {
        this.blank1 = blank1 == null ? null : blank1.trim();
    }

    public String getBlank2() {
        return blank2;
    }

    public void setBlank2(String blank2) {
        this.blank2 = blank2 == null ? null : blank2.trim();
    }

    public String getBlank3() {
        return blank3;
    }

    public void setBlank3(String blank3) {
        this.blank3 = blank3 == null ? null : blank3.trim();
    }
}