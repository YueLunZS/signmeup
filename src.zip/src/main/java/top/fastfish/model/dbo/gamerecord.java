package top.fastfish.model.dbo;

public class gamerecord {
    private Integer gameId;

    private String endingtime;

    private String createtime;

    private String initialBonus;

    private String averageBonus;

    private String playersCount;

    private String winnersCount;

    private String initiator;

    private String bei;

    private String blank1;

    private String blank2;

    private String blank3;

    public Integer getGameId() {
        return gameId;
    }

    public void setGameId(Integer gameId) {
        this.gameId = gameId;
    }

    public String getEndingtime() {
        return endingtime;
    }

    public void setEndingtime(String endingtime) {
        this.endingtime = endingtime == null ? null : endingtime.trim();
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime == null ? null : createtime.trim();
    }

    public String getInitialBonus() {
        return initialBonus;
    }

    public void setInitialBonus(String initialBonus) {
        this.initialBonus = initialBonus == null ? null : initialBonus.trim();
    }

    public String getAverageBonus() {
        return averageBonus;
    }

    public void setAverageBonus(String averageBonus) {
        this.averageBonus = averageBonus == null ? null : averageBonus.trim();
    }

    public String getPlayersCount() {
        return playersCount;
    }

    public void setPlayersCount(String playersCount) {
        this.playersCount = playersCount == null ? null : playersCount.trim();
    }

    public String getWinnersCount() {
        return winnersCount;
    }

    public void setWinnersCount(String winnersCount) {
        this.winnersCount = winnersCount == null ? null : winnersCount.trim();
    }

    public String getInitiator() {
        return initiator;
    }

    public void setInitiator(String initiator) {
        this.initiator = initiator == null ? null : initiator.trim();
    }

    public String getBei() {
        return bei;
    }

    public void setBei(String bei) {
        this.bei = bei == null ? null : bei.trim();
    }

    public String getBlank1() {
        return blank1;
    }

    public void setBlank1(String blank1) {
        this.blank1 = blank1 == null ? null : blank1.trim();
    }

    public String getBlank2() {
        return blank2;
    }

    public void setBlank2(String blank2) {
        this.blank2 = blank2 == null ? null : blank2.trim();
    }

    public String getBlank3() {
        return blank3;
    }

    public void setBlank3(String blank3) {
        this.blank3 = blank3 == null ? null : blank3.trim();
    }
}