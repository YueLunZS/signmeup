package top.fastfish.model.dbo;

import top.fastfish.model.pojo.user;

public class admin extends user {
    private Integer id;

    private String account;

    private String pass;

    private String rightlv;

    private String bei;

    private String blank1;

    private String blank2;

    private String blank3;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass == null ? null : pass.trim();
    }

    public String getRightlv() {
        return rightlv;
    }

    public void setRightlv(String rightlv) {
        this.rightlv = rightlv == null ? null : rightlv.trim();
    }

    public String getBei() {
        return bei;
    }

    public void setBei(String bei) {
        this.bei = bei == null ? null : bei.trim();
    }

    public String getBlank1() {
        return blank1;
    }

    public void setBlank1(String blank1) {
        this.blank1 = blank1 == null ? null : blank1.trim();
    }

    public String getBlank2() {
        return blank2;
    }

    public void setBlank2(String blank2) {
        this.blank2 = blank2 == null ? null : blank2.trim();
    }

    @Override
    public String getBlank3() {
        return blank3;
    }

    @Override
    public void setBlank3(String blank3) {
        this.blank3 = blank3 == null ? null : blank3.trim();
    }
}