package top.fastfish.model.dbo;

public class bill {
    private Integer billId;

    private Integer walletId;

    private Integer playerId;

    private String walletRemainder;

    private String trandeAmount;

    private String trandeTime;

    private String trandeType;

    private String bei;

    private Integer gameId;

    private String blank1;

    private String blank2;

    private String blank3;

    public Integer getBillId() {
        return billId;
    }

    public void setBillId(Integer billId) {
        this.billId = billId;
    }

    public Integer getWalletId() {
        return walletId;
    }

    public void setWalletId(Integer walletId) {
        this.walletId = walletId;
    }

    public Integer getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Integer playerId) {
        this.playerId = playerId;
    }

    public String getWalletRemainder() {
        return walletRemainder;
    }

    public void setWalletRemainder(String walletRemainder) {
        this.walletRemainder = walletRemainder == null ? null : walletRemainder.trim();
    }

    public String getTrandeAmount() {
        return trandeAmount;
    }

    public void setTrandeAmount(String trandeAmount) {
        this.trandeAmount = trandeAmount == null ? null : trandeAmount.trim();
    }

    public String getTrandeTime() {
        return trandeTime;
    }

    public void setTrandeTime(String trandeTime) {
        this.trandeTime = trandeTime == null ? null : trandeTime.trim();
    }

    public String getTrandeType() {
        return trandeType;
    }

    public void setTrandeType(String trandeType) {
        this.trandeType = trandeType == null ? null : trandeType.trim();
    }

    public String getBei() {
        return bei;
    }

    public void setBei(String bei) {
        this.bei = bei == null ? null : bei.trim();
    }

    public Integer getGameId() {
        return gameId;
    }

    public void setGameId(Integer gameId) {
        this.gameId = gameId;
    }

    public String getBlank1() {
        return blank1;
    }

    public void setBlank1(String blank1) {
        this.blank1 = blank1 == null ? null : blank1.trim();
    }

    public String getBlank2() {
        return blank2;
    }

    public void setBlank2(String blank2) {
        this.blank2 = blank2 == null ? null : blank2.trim();
    }

    public String getBlank3() {
        return blank3;
    }

    public void setBlank3(String blank3) {
        this.blank3 = blank3 == null ? null : blank3.trim();
    }
}