package top.fastfish.model.gamemodel;

import top.fastfish.util.ConfigParam;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description:共有的游戏实体
 * @date 2018/11/1
 */
public class PublicSimpleGameA {
    /**
     * 对应游戏记录的序列号
     */
    public static Integer gameId;
    /**
     * 重设id的权限参数
     */
    private static Long idFlag = (long) 0;
    /**
     * 游戏结束时间
     */
    public static Long endingTime = (long) 0;
    /**
     * 累计总金额
     */
    public static Integer amountMoney = 0;
    /**
     * 参与者和参与时间点,系统预约的默认时间为游戏开始时间(endingTime-30*60*1000);
     */
    public static Map<Integer, Long> game1Players = new HashMap<>();
    /**
     * 成功打卡的参与者和打卡时间点
     */
    public static Map<Integer, Long> successPlayers = new HashMap<>();

    /**
     * 设置id的方法,12小时内只能被执行一次
     */
    public static void setGameId(Integer gameId) {
        long nowTime = System.currentTimeMillis();
        if ((nowTime - idFlag) > ConfigParam.HALFDAY) {
            PublicSimpleGameA.gameId = gameId;
            idFlag = nowTime;
        }
    }

    public static void setEndingTime(Long endingTime) {
        PublicSimpleGameA.endingTime = endingTime;
    }

    public static void setAmountMoney(Integer amountMoney) {
        PublicSimpleGameA.amountMoney = amountMoney;
    }

    public static void setGame1Players(Map<Integer, Long> game1Players) {
        PublicSimpleGameA.game1Players = game1Players;
    }

    public static void setSuccessPlayers(Map<Integer, Long> successPlayers) {
        PublicSimpleGameA.successPlayers = successPlayers;
    }


}
