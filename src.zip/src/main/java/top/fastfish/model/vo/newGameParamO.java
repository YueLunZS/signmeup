package top.fastfish.model.vo;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: Object4createGameParam
 * @date 2018/11/1
 */
public class newGameParamO {
    private String gameType;

    public String getGameType() {
        return gameType;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }
}
