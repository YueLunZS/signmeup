package top.fastfish.model.vo;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description:
 * @date 2018/11/1
 */
public class LoginParamO {
    private String account;
    private String pass;
    private String classification;
    private String signPath;//判断登录方式的字段,normal=账户密码正常登录



    public LoginParamO() {
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getSignPath() {
        return signPath;
    }

    public void setSignPath(String signPath) {
        this.signPath = signPath;
    }
}
