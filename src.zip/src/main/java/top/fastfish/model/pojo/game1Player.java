package top.fastfish.model.pojo;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description:
 * @date 2018/11/1
 */
public class game1Player {


}
