package top.fastfish.model.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: gameparamMap,model No.2 weeklyGame
 * @date 2018/10/23
 */
public class game2 {
    private static Map<String, Object> param = new HashMap<String,Object>();

    private static List<String> paramNames = new ArrayList<>();

    public static Map<String, Object> getParam() {
        return param;
    }

    public static List<String> getParamNames() {
        return paramNames;
    }

    private void setParam(Map<String, Object> param) {
        game2.param = param;
    }

    private void setParamNames(List<String> paramNames) {
        game2.paramNames = paramNames;
    }

    private void addParam (String paramName){
        param.put(paramName,null);
        paramNames.add(paramName);
    }


}
