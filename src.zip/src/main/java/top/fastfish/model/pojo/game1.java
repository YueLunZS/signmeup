package top.fastfish.model.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: gameparamMap,model No.1 dailyGame
 * @date 2018/10/23
 */
public class game1 {
    private static String[] paramNames = {"gameNum","","","","","","","","","","",""};


    private static Map<String, Object> param = new HashMap<String,Object>();

    public static Map<String, Object> getParam() {return param;}

    public static String[] getParamNames() { return paramNames; }




}
