package top.fastfish.model.pojo;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 所有账户的共同父类
 * @date 2018/11/1
 */
public class user {
    private String blank3;

    public user() {
    }

    public String getBlank3() {
        return blank3;
    }

    public void setBlank3(String blank3) {
        this.blank3 = blank3;
    }
}
