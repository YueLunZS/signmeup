package top.fastfish.model.pojo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 游戏模型
 * @date 2018/10/23
 */
public class game {

    private Map<String, Object> gameparam = new HashMap<String,Object>();

    private List<Integer> playerIdList = new ArrayList<>();


    public game getInstanceOfGame1(){
        game game = new game();
        this.gameparam = game1.getParam();
        return game;
    }

    public game getInstanceOfGame2(){
        game game = new game();
        this.gameparam = game2.getParam();
        return game;
    }
}
