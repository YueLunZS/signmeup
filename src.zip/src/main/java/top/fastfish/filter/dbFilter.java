package top.fastfish.filter;

import top.fastfish.model.dbo.admin;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 保护服务器数据,对敏感数据的请求做权限判断
 * @date 2018/10/26
 */
@WebFilter(filterName = "dbFilter")
public class dbFilter implements Filter {
    @Override
    public void destroy() {
    }

    @SuppressWarnings("AlibabaLowerCamelCaseVariableNaming")
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        @SuppressWarnings("AlibabaLowerCamelCaseVariableNaming") String URL = req.getRequestURI();
        HttpSession session = req.getSession();
        admin aUser = (admin) session.getAttribute("uAdmin");
        if (URL.indexOf(".db.do") > 0) {
            if (aUser != null) {
                chain.doFilter(req, resp);
                return;
            } else {
                System.out.println("requestDenies:没有权限访问敏感资源! URL="+URL);
                request.setAttribute("frontendException","没有权限访问敏感资源");
                request.getRequestDispatcher("/mobile/html/erorr.jsp").forward(request, response);
                return;
            }

        } else if (URL.indexOf(".wallet.do") > 0) {
            if ("highest".equals(aUser.getRightlv())){
                chain.doFilter(req, resp);
                return;
            }else {
                System.out.println("requestDenies:没有权限访问敏感资源! URL="+URL);
                request.setAttribute("frontendException","没有权限访问敏感资源");
                request.getRequestDispatcher("/mobile/html/erorr.jsp").forward(request, response);
                return;
            }

        } else {
            chain.doFilter(req, resp);
            return;
        }


    }

    @Override
    public void init(FilterConfig config) throws ServletException {

    }

}
