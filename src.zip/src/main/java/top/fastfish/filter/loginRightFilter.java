package top.fastfish.filter;

import top.fastfish.model.dbo.admin;
import top.fastfish.model.dbo.player;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @author zhaoshuo
 * @version 2.0
 * Description:未登录页面全部跳转至登录页
 */
@WebFilter(filterName = "loginRightFilter")
public class loginRightFilter implements Filter {

    @SuppressWarnings("AlibabaLowerCamelCaseVariableNaming")
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        //noinspection AlibabaLowerCamelCaseVariableNaming
        String URL = req.getRequestURI();
        HttpSession session = req.getSession();
        player pUser = (player) session.getAttribute("uPlayer");
        admin aUser = (admin) session.getAttribute("uAdmin");
        if (pUser != null) {
            chain.doFilter(req, resp);
            return;
        }
        if (aUser != null) {
            chain.doFilter(req, resp);
            return;
        }
        if (URL.indexOf("login") > 0
                || URL.indexOf("login") > 0
                || URL.indexOf("index") > 0
                || URL.indexOf("images") > 0
                || URL.indexOf("js") > 0
                || URL.indexOf("visitor") > 0
//                || URL.indexOf("ico") > 0
//                || URL.equals("/")
                ) {
            chain.doFilter(req, resp);
        }else{
            System.out.println("requestDenies:没有权限访问敏感资源! URL="+URL);
            ((HttpServletResponse) response).sendRedirect("index.html");
            return;
        }


    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }
}
