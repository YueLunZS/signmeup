package top.fastfish.service;

import java.util.Map;
import java.util.Set;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 管理简单游戏A
 * @date 2018/11/6
 */
public interface PublicSimpleGameAService {
    /**开局方法,需要一个身份认证和一个时间戳.(若参数包括初始奖金池金额,则先往奖池中投入这部分钱)
     *
     * @param key 身份识别钥匙
     * @param timeStamp 签到时间线
     * @param initialMoney 初始奖金池金额,单位为分
     * @param playersId 默认预约的用户id集合
     */
     void initPublicSimpleGameA(String key, Long timeStamp, Integer initialMoney, Set<Integer> playersId);

    /**结算方法,需要一个身份认证,返回一个结算金额列表,不做账面计算(若参数包括初始奖金池金额,则先扣去这部分钱)
     *
     * @param key 身份识别钥匙
     * @param initialMoney 需要返回的初始奖金数额,单位为分
     * @return 一个签到成功用户的id和对应应得钱数额(分)的集合(用于账目计算)
     */
     Map<Integer, String> clearPublicSimpleGameA(String key, Integer initialMoney);

    /**
     * 玩家个人预约的方法,需要判断玩家余额足够后再放ta加入游戏
     * @param playerId 玩家id
     * @param gameId 游戏id
     */
    boolean joinGame(Integer playerId,Integer gameId);

    /**
     * 签到方法,先判断有没有提前参加这次打卡,然后记录打卡信息
     * @param playerId 玩家id
     * @param gameId 游戏id
     * @return 成功与否
     */
    boolean signUp(Integer playerId,Integer gameId);
}
