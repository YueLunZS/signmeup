package top.fastfish.service;

import top.fastfish.model.pojo.user;
import top.fastfish.model.vo.LoginParamO;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description:
 * @date 2018/11/1
 */
public interface LoginService {
    //是否允许登录
    user isPermitted(LoginParamO paramO);
}
