package top.fastfish.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.fastfish.mapper.adminMapper;
import top.fastfish.mapper.playerMapper;
import top.fastfish.model.pojo.user;
import top.fastfish.model.vo.LoginParamO;
import top.fastfish.service.LoginService;

import java.util.regex.Pattern;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 用户控制
 * @date 2018/11/1
 */
@Service
public class LoginServiceImpl implements LoginService {
    @Autowired
    private playerMapper pMapper;
    @Autowired
    private adminMapper aMapper;


    private String telRegex = "[1][3578]\\d{9}";
    private user user;

    @Override
    public user isPermitted(LoginParamO paramO) {
        if ("normal".equals(paramO.getSignPath())) {
            if ("player".equals(paramO.getClassification())) {
                if (Pattern.matches(telRegex, paramO.getAccount())) {
                    user = pMapper.checkWithTEL(paramO.getAccount(), paramO.getPass());
                } else {
                    user = pMapper.checkWithAccount(paramO.getAccount(), paramO.getPass());
                }

            } else if ("admin".equals(paramO.getClassification())) {
                user = aMapper.checkWithAccount(paramO.getAccount(), paramO.getPass());
            }
        }
        return user;
    }

}
