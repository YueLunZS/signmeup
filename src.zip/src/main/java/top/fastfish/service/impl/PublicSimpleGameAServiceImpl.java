package top.fastfish.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.fastfish.mapper.billMapper;
import top.fastfish.mapper.gamerecordMapper;
import top.fastfish.mapper.playerMapper;
import top.fastfish.mapper.walletMapper;
import top.fastfish.model.dbo.gamerecord;
import top.fastfish.model.dbo.player;
import top.fastfish.model.dbo.wallet;
import top.fastfish.model.gamemodel.PublicSimpleGameA;
import top.fastfish.service.PublicSimpleGameAService;
import top.fastfish.util.ConfigParam;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description:
 * @date 2018/11/6
 */
@Service
public class PublicSimpleGameAServiceImpl implements PublicSimpleGameAService {

    @Autowired
    private gamerecordMapper gMapper;
    @Autowired
    private playerMapper pMapper;
    @Autowired
    private walletMapper wMapper;
    @Autowired
    private billMapper bMapper;

    @Override
    public void initPublicSimpleGameA(String key, Long timeStamp, Integer initialMoney, Set<Integer> playersId) {
        if (!ConfigParam.SIMPLEGAME_KEY1.equals(key)) {
            return;
        }
        //新游戏需要在游戏结束12小时前开启(可设置在上一次打卡活动结束后若干时间开始)
        long nowTime = System.currentTimeMillis();
        if ((nowTime - timeStamp) > ConfigParam.HALFDAY) {
            PublicSimpleGameA.setEndingTime(timeStamp);
        } else {
            return;
        }
        if (initialMoney == null) {
            initialMoney = 0;
        }
        PublicSimpleGameA.setAmountMoney(initialMoney);
        Long startTime = timeStamp - (ConfigParam.SIMPLEGAME_SIGNTIME);
        HashMap<Integer, Long> gamePlayers = new HashMap<>(16);
        for (Integer playerId : playersId) {
            gamePlayers.put(playerId, startTime);
        }
        PublicSimpleGameA.setGame1Players(gamePlayers);
        PublicSimpleGameA.setAmountMoney(playersId.size()*ConfigParam.SIMPLEGAME_DEPOSIT);
        //存库
        gamerecord gRecord = new gamerecord();
        gRecord.setCreatetime(String.valueOf(nowTime));
        gRecord.setEndingtime(String.valueOf(timeStamp));
        gRecord.setInitialBonus(initialMoney.toString());
        gRecord.setAverageBonus("0");
        gRecord.setPlayersCount(playersId.toString());
        gRecord.setWinnersCount("0");
        gRecord.setInitiator("system");
        gRecord.setBlank1(ConfigParam.SIMPLEGAME_DEPOSIT.toString());
        int insert = gMapper.insert(gRecord);
        //记录打卡活动序列号(id)
        int id = gMapper.selectByCreatetime(String.valueOf(nowTime));
        PublicSimpleGameA.setGameId(id);
        return;
    }

    @Override
    public Map<Integer, String> clearPublicSimpleGameA(String key, Integer initialMoney) {
        if (!ConfigParam.SIMPLEGAME_KEY1.equals(key)) {
            return null;
        }
        if (initialMoney != null) {
            PublicSimpleGameA.amountMoney -= initialMoney;
        }
        Set<Integer> keys = PublicSimpleGameA.successPlayers.keySet();
        //平均奖金(计算到厘)
        DecimalFormat df = new DecimalFormat("0.00");
        int winnersCount = keys.size();
        String averageBonus = df.format((float) PublicSimpleGameA.amountMoney / winnersCount);
        Map<Integer, String> clearMap = new HashMap<>(16);
        for (Integer pId : keys) {
            clearMap.put(pId,averageBonus);
        }
        gamerecord gRecord = new gamerecord();
        gRecord.setAverageBonus(averageBonus);
        gRecord.setWinnersCount(String.valueOf(winnersCount));
        int i = gMapper.updateByPrimaryKeySelective(gRecord);
        if (i==1){
            return clearMap;
        }
        return null;
    }

    @Override
    public boolean joinGame(Integer playerId, Integer gameId) {
        //获取账户信息,对余额和时间做判断
        if (PublicSimpleGameA.gameId.equals(gameId)){
            return false;
        }
        player player = pMapper.selectByPrimaryKey(playerId);
        Integer walletId = player.getWalletId();
        wallet wallet = wMapper.selectByPrimaryKey(walletId);
        if (wallet==null){
            return false;
        }
        int remainder = Integer.parseInt(wallet.getWalletRemainder());
        Long nowTime = System.currentTimeMillis();
        if (remainder < ConfigParam.SIMPLEGAME_DEPOSIT || nowTime >(PublicSimpleGameA.endingTime - ConfigParam.SIMPLEGAME_SIGNTIME)){
            return false;
        }
        //修改余额,操作记录写入账单
        wallet.setWalletRemainder(String.valueOf(remainder-ConfigParam.SIMPLEGAME_DEPOSIT));
        wallet.setUpdatetime(String.valueOf(nowTime));
        int update1 = wMapper.updateByPrimaryKey(wallet);
        //先更新PublicSimpleGameA的信息
        PublicSimpleGameA.game1Players.put(playerId,nowTime);
        PublicSimpleGameA.setAmountMoney(PublicSimpleGameA.amountMoney+ConfigParam.SIMPLEGAME_DEPOSIT);
        //更新gameRecord表
        gamerecord gRecord = gMapper.selectByPrimaryKey(PublicSimpleGameA.gameId);
        gRecord.setPlayersCount(gRecord.getPlayersCount()+1);
        int update2 = gMapper.updateByPrimaryKey(gRecord);
        return true;
    }

    @Override
    public boolean signUp(Integer playerId, Integer gameId) {
        //获取账户信息,对账户id和时间做判断
        if (PublicSimpleGameA.gameId.equals(gameId)){
            return false;
        }
        if (PublicSimpleGameA.game1Players.get(playerId)==null){
            return false;
        }
        Long nowTime = System.currentTimeMillis();
        if (nowTime<(PublicSimpleGameA.endingTime - ConfigParam.SIMPLEGAME_SIGNTIME) || nowTime > PublicSimpleGameA.endingTime){
            return false;
        }
        //先更新PublicSimpleGameA的信息
        PublicSimpleGameA.successPlayers.put(playerId,nowTime);
        //更新gameRecord表
        gamerecord gRecord = gMapper.selectByPrimaryKey(PublicSimpleGameA.gameId);
        gRecord.setWinnersCount(gRecord.getWinnersCount()+1);
        int update2 = gMapper.updateByPrimaryKey(gRecord);
        return false;
    }

}
