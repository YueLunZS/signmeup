package top.fastfish.controller;

import com.alibaba.fastjson.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.fastfish.model.dbo.admin;
import top.fastfish.model.dbo.player;
import top.fastfish.model.pojo.user;
import top.fastfish.model.vo.LoginParamO;
import top.fastfish.service.LoginService;
import top.fastfish.util.Msg;

import javax.servlet.http.HttpSession;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 注册登录相关逻辑
 * @date 2018/10/26
 */
@RestController
@RequestMapping(value = "login")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @RequestMapping(value = "/login.do", produces = "text/html;charset=UTF-8")
    public String playerLogin(String loginParam, HttpSession session) {
        LoginParamO paramO = JSON.parseObject(loginParam, LoginParamO.class);
        paramO.setSignPath("normal");
        user user = loginService.isPermitted(paramO);
        if (user != null) {
            String userType = user.getBlank3();
            if ("p".equals(userType)) {
                player player = (player) user;
                session.setAttribute("uPlayer", player);
                System.out.println(paramO.getClassification() + "用户<" + paramO.getAccount() + ">登录成功");
                return JSON.toJSONString(Msg.success());
            }
            if ("a".equals(userType)) {
                admin admin = (admin) user;
                session.setAttribute("uAdmin", admin);
                System.out.println(paramO.getClassification() + "用户<" + paramO.getAccount() + ">登录成功");
                return JSON.toJSONString(Msg.success());
            }

            return JSON.toJSONString(Msg.fail().add("msg", "用户身份不明"));
        } else {
            return JSON.toJSONString(Msg.fail().add("msg", "账号名密码错误"));
        }
    }
}
