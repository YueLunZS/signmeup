package top.fastfish.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 测试
 * @date 2018/10/26
 */
@RestController
public class TestController {

    @RequestMapping(value = "test.db.do",produces = "text/html;charset=UTF-8")
    public String dbFilterTest(HttpSession session){
        System.out.println(1);
        return "SUCCESS";
    }
}
