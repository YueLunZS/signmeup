package top.fastfish.controller;

import com.alibaba.fastjson.JSON;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.fastfish.model.vo.newGameParamO;

import javax.servlet.http.HttpSession;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 游戏开始和结束
 * @date 2018/11/1
 */
@RestController
public class GameController {

    @RequestMapping(value = "newGameParam",produces = "text/html;charset=UTF-8")
    public String newGame(String gameParam, HttpSession session){
        newGameParamO paramO = JSON.parseObject(gameParam, newGameParamO.class);
        String gameType = paramO.getGameType();
        if ("simple".equals(gameType)){

        }
        return null;
    }
}
