package top.fastfish.util;

/**
 * @author zhaoshuo
 * @version 1.0
 * Description: 各种定义好的参数值
 * @date 2018/11/6
 */
public class ConfigParam {
    //简单打卡每次投入金额(分)
    public final static Integer SIMPLEGAME_DEPOSIT  = 500;
    //简单打卡打卡时间窗口长度(ms)
    public final static Integer SIMPLEGAME_SIGNTIME  = 30*60*1000;
    //游戏发起需要的提前时间
    public final static Integer HALFDAY  = 12*60*60*1000;
    //开启简单游戏需要的身份认证
    public final static String SIMPLEGAME_KEY1  = "张龙赵虎";
}
