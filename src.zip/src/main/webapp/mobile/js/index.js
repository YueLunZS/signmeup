/**
 * @author zhaoshuo
 * @date 2018/10/26
 * @version 1.0
 * Description: 注册登录页
 */
$(function () {
    //单选项默认为玩家
    $('input:radio:first').attr('checked', 'checked');


    $("#loginButton").click(function () {
        $("#messageMask").html("正在提交数据，请勿关闭当前窗口...");

        $.ajax({
            url: "../../login/login.do",
            async: false,
            data: "loginParam="+GetAccountJsonParam(),
            type: "POST",
            success: function (data) {
                var Msg = JSON.parse(data);
                if (Msg.code ==100) {
                    window.location.href = "hall.html";
                }
                if (Msg.code ==200) {
                    $("#messageMask").html("账号密码错误,请查证后继续登录!");
                }

            },
            error: function (data) {
                $("#request-process-patent").html("提交数据失败！");
            }
        });
    });

    function GetAccountJsonParam() {
        var json = {
            "account": $('#loginAccount').val(),
            "pass": $('#loginPass').val(),
            "classification": $('input:radio[name="classification"]:checked').val()
        };
        return JSON.stringify(json);
    }


});