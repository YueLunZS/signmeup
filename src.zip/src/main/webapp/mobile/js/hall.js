/**
 * @author zhaoshuo
 * @date 2018/10/26
 * @version 1.0
 * Description:
 */
$(function () {
    var str = "2018年";
    function showTime() {
        var nowtime = new Date();
        var year = nowtime.getFullYear();
        var month = nowtime.getMonth() + 1;
        var date = nowtime.getDate();
        var myday =  year + "年" + month + "月" + date + "日";

        var HH = nowtime.getHours();
        var MM = nowtime.getMinutes();
        var SS = nowtime.getSeconds();
        // var mytime =  nowtime.toLocaleTimeString();
        var mytime =   HH + "时" + MM + "分" + SS + "秒";
        str = myday+mytime;
        $('#myday').html(myday);
        $('#mytime').html(mytime);
    }
    setInterval(showTime, 1000);

    $('#signUp').click(function () {

        alert(str)

    });

    $('#bespeak').click(function () {

        alert("预约成功,记得明天7:30--8:00间打卡哦!")

    });

});

